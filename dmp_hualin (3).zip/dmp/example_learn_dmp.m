%% Example Learn DMP
% Learn a DMP using a min_jerk trajectory as template

% init a dmp
n_bfs = 10;
dt = 0.01;
dm = dmp(n_bfs);


% generate a minimal jerk trajectory as a sample
%[t, Y, Yd, Ydd] = dmp.generate_trajectory_jerk(0, 1, 0.5, dt);


% learn dmp using batch data
dt = 0.01
Y = y_position
Yd = y_velocity
Ydd = y_jerk
dm.batch_fit(dt, Y, Yd, Ydd);
% plot
[t1,s1] = dm.rollout(0.5);

figure(1)
hold on
t = 0.01
plot(t,Y)
plot(t1,s1(2,:))
hold off
legend('Sample','Learned')
