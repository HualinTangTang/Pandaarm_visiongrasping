function [ theta ] = get_dmps_w( dmps )
%GET_DMPS_W Summary of this function goes here
%   Detailed explanation goes here
    [m,n] = size(dmps);
    
    k = 1;
    for j=1:n
        for i=1:m
        theta(k:k+dmps(i,j).n_bfs-1,1) = dmps(i,j).w;
        k = k+dmps(i,j).n_bfs;
        end
    end

end

