function [ mps ] = init_dmps( n, n_bfs, tau, dt, y0, g, flag )
%INIT_DMPS Summary of this function goes here
%   Detailed explanation goes here
mps = repmat(dmp(n_bfs),n,1);
for i = 1:n
    mps(i) = dmp(n_bfs, tau, y0(i), g(i));
    mps(i).dt = dt;
    if (flag == 1) && (y0(i)~= g(i))
        mps(i) = mps(i).init_minjerk(); 
    end
end


end

