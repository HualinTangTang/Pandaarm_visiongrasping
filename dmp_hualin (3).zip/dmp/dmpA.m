classdef dmpA < handle
    %DMPDMP where A is fixed
    
    properties
        %%%% parameters of forcing term
        sigma
        c
        w % weights
        n_bfs
        %%%% initial position and goal position
        y0 = 0
        g = 1
        
        %%%% alpha_z, beta_z
        az = 12 % 6.25 in literature, but tuned here to make it nerely converge around t = tau 
        bz = 12/4
        tau = 0.5
        %%%%
        ax = 6.25/1.5
        x0 = 1
        %%%%
        dt = 0.001
        
        %%%%
        dG
        A = 1 % maximal amplitude
        %sf
        
        %%%% constraints on acceleration, velocity, position
        min_yd = -inf %-6.8 % 6.8 rad/s when run at Voltage > 6.8 for Hitec servo 7950
        max_yd = inf  %6.8
        min_y = -inf
        max_y = inf
        %min_zd = -inf
        %max_zd = inf
        %%%%
    end
    
    methods
        function obj = dmp(varargin)
            % input: n_bfs
            % input: n_bfs, dmp_tau
            % input: n_bfs, dmp_tau, y0, g
            % input: n_bfs, dmp_tau, y0, g, A
            switch nargin
                case 1
                    obj.n_bfs = varargin{1};
                case 2
                    obj.n_bfs = varargin{1};
                    obj.tau   = varargin{2};
                case 4
                    obj.n_bfs = varargin{1};
                    obj.tau   = varargin{2};
                    obj.y0    = varargin{3};
                    obj.g     = varargin{4};
                    obj.A     = obj.g - obj.y0;
                case 5
                    obj.n_bfs = varargin{1};
                    obj.tau   = varargin{2};
                    obj.y0    = varargin{3};
                    obj.g     = varargin{4};
                    obj.A     = varargin{5};
            end
            
            t = (0:1/(obj.n_bfs-1):1)'*obj.tau;
            obj.c = exp(-(obj.ax/obj.tau)*t);
            D = diff(obj.c)*obj.tau*1.1;
            %D = 1./[D;D(end)];
            obj.sigma = [D;D(end)];
            obj.w = zeros(obj.n_bfs,1);
        end
        function [obj] = modify(obj, varargin)
            % input: y0, g
            % input: y0, g, A
            switch length(varargin)
                case 2
                    obj.y0 = varargin{1};
                    obj.g  = varargin{2};
                    if obj.g - obj.y0 ~= 0
                        obj.A = obj.g - obj.y0;
                    end
                case 3
                    obj.y0    = varargin{1};
                    obj.g     = varargin{2};
                    obj.A     = varargin{3};
            end
        end
        
        function f = fnctF(obj, x)
            psi = obj.fnctPsi(x);
            a = obj.A;
            % a = obj.g - obj.y0;
            f = (psi'*obj.w)'./sum(psi,1) .*x*a;
            
        end
        
        function psi = fnctPsi(obj, x)
            x = repmat(x,length(obj.c),1); % for vectorised x
            h = 1./(obj.sigma.^2);
            psi = exp(-0.5*((x - obj.c ).^2).*h );
        end
        
        function dX = dynm(obj, X)
            % dynamics of y
            % first order form
            % X: [z;y;x]
            f = obj.fnctF(X(3,:));
            dz = (obj.az*(obj.bz*(obj.g - X(2,:))- X(1,:)) + f)/obj.tau ;
            dy = X(1,:)/obj.tau;
            dx = -obj.ax*X(3,:)/obj.tau;
            
            % to-do: impose constraint
            %dy = min(max(dy,obj.min_yd), obj.max_yd);
            %--------------%
            %range = obj.max_yd - obj.min_yd; 
            %dy = tanh(dy/(range/2))*range;
            %
            dX = [dz;dy;dx];
        end
        
        function sn = step(obj, s, sdt)
            ds = obj.dynm(s);
            sn = s + ds*sdt;
            
            % to-do: impose constraint?
            %sn(2,:) = min(max(sn(2,:),obj.min_y), obj.max_y);
        end
        
        function [varargout] = rollout(obj, varargin)
            % output: t, z, y, x
            T = varargin{1};
            if length(varargin) > 1
                sdt = varargin{2};
            else
                sdt = obj.dt;
            end
            Nt = T/sdt + 1;
            s = zeros(3,Nt);
            % s(1,1) = 
            s(2,1) = obj.y0;
            s(3,1) = obj.x0;
            t = 0:sdt:T;
            for i = 1:Nt-1
                s(:,i+1) = obj.step(s(:,i), sdt);
            end
            
            if nargout == 1
                varargout{1} = struct('t', t, 'z', s(1,:), 'y', s(2,:), 'x', s(3,:));
            elseif nargout == 2
                varargout{1} = t;
                varargout{2} = s;
                
            elseif nargout == 3
                varargout{1} = t;
                varargout{2} = s(1,:);
                varargout{3} = s(2,:);
            elseif nargout == 4
                varargout{1} = t;
                varargout{2} = s(1,:);
                varargout{3} = s(2,:);
                varargout{4} = s(3,:);
            else
                disp('wrong output specs')
            end
        end
        
        function [obj, w] = batch_fit(obj, dt, Y, Yd, Ydd)
            y00 = Y(1);
            goal = Y(end);
            obj.A = max(Y) - min(Y);
            obj.dG = goal - y00;
            %obj.sf = 1;
            
            %amp = obj.sf;
            t = 0:dt:dt*(length(Y)-1);
            x = exp( - ( obj.ax/obj.tau )*t );
            % force term target
            % in the original code from Schaal, Ft is divided by a scaling
            % factor, and when calculate the forcing term, it multiply the
            % scaling factor s. s represent relative scaling to the learned
            % trajectory. 
            Ft  = (Ydd*obj.tau^2 - obj.az*(obj.bz*(goal-Y) - obj.tau*Yd));
            if size(Ft,1) == 1
                Ft = Ft';
            end
            PSI = obj.fnctPsi(x);
            
            sx2 = sum(repmat(x.^2, obj.n_bfs, 1).*PSI*obj.A^2, 2);
            sxtd = repmat(x, obj.n_bfs, 1).*PSI*obj.A*Ft;
            w = sxtd./sx2;
            obj.w = w;
        end
        
        function [obj, w] = init_minjerk(obj)
            [~, x_mj, xd_mj, xdd_mj] = generate_trajectory_jerk(obj.y0, obj.g, obj.tau, obj.dt);
            [obj, w] = obj.batch_fit(obj.dt, x_mj, xd_mj, xdd_mj);
            
        end
    end
    
end

function [t, x, xd, xdd] = generate_trajectory_jerk(x0, xf, tf, dt)
    t = 0:dt:tf;
    
    tau = t/tf;
    
    x = x0 + (x0 - xf)*( 15*tau.^4 - 6*tau.^5 - 10*tau.^3 );

    %xdot = (x(:,3:end) - x(:,1:end-2))/(2*dt) ;
    %xdot = [zeros(size(x0)),xdot,zeros(size(x0))];
    
    xd = gradient(x)./dt;
    %xddot = (x(:,3:end) + x(:,1:end-2) - 2*x(:,2:end-1) )/(dt^2);
    %xddot = [zeros(size(x0)),xddot,zeros(size(x0))];
    xdd = gradient(xd)./dt;
end