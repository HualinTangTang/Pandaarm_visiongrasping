function [ dmps ] = update_dmps_w( dmps, theta )
% update dmps (stucture array of CLASS dmp) weights using theta
% note: must return the dmps as they are value class objects
    k = 1;
    n_dmps = length(dmps);
    for i=1:n_dmps
        dmps(i).w = theta(k:k+dmps(i).n_bfs-1);
        k = k+dmps(i).n_bfs;
    end

end

