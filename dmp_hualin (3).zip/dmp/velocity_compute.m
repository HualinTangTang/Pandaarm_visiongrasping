position_data = load('/home/mirmi/teachingdata/demo_position.txt');
time_step = 0.001
C = diff(position_data)/time_step
%fid=fopen('/home/mirmi/teachingdata/matlab_velocity','wt');
%fprintf(fid,'%d',C);
%fclose(fid);%关闭文件

row=size(C,1);
col=size(C,2);
fid=fopen(['/home/mirmi/teachingdata/matlab_velocity.txt'],'wt');
for i=1:row
for j=1:col
fprintf(fid,'%g ',C(i,j));
end
fprintf(fid,'\n');
end
fclose(fid);
