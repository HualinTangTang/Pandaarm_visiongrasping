velocity_data = load('/home/mirmi/teachingdata/matlab_velocity.txt')
time_step = 0.001
C1 = diff(velocity_data)/time_step
%fid=fopen('/home/mirmi/teachingdata/matlab_velocity','wt');
%fprintf(fid,'%d',C);
%fclose(fid);%关闭文件

row1=size(C1,1);
col1=size(C1,2);
fid1=fopen(['/home/mirmi/teachingdata/matlab_jerk.txt'],'wt');
for i=1:row1
for j=1:col1
fprintf(fid1,'%g ',C1(i,j));
end
fprintf(fid1,'\n');
end
fclose(fid1);
