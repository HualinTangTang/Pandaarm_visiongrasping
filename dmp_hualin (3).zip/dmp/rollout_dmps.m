function [ res ] = rollout_dmps( dmps, T, varargin )
%ROLLOUT_DMPS Summary of this function goes here
%   Detailed explanation goes here
    n = length(dmps);
    
    if ~isempty(varargin)
        dt = varargin{1}; 
    else
        dt = dmps(1).dt;
    end
    
    res = dmps(1).rollout(T, dt);
    
    if n > 1
        res(1:n) = res;
        for i=2:length(dmps)
            res(i) = dmps(i).rollout(T, dt);        
        end
    end
end

